import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, delay, of } from 'rxjs';

export interface Message {
  id: string;
  sender: string;
  subject: string;
  date: Date;
  status: 'read' | 'unread';
  messageBody: string;
  topic?: string;
  email?: string;
  userName?: string;
  accountId?: string;
  serviceId?: string;
  language?: string;
  product?: string;
  environment?: string;
}

export interface SendMessageRequest {
  topic: string;
  subject: string;
  email: string;
  message: string;
  userName: string;
  accountId: string;
  serviceId: string;
  language: string;
  product: string;
  environment: string;
}

@Injectable({
  providedIn: 'root'
})
export class MessageService {
  private messagesSource = new BehaviorSubject<Message[]>(this.getMockMessages());
  public messages$ = this.messagesSource.asObservable();

  private getMockMessages(): Message[] {
    return [
      {
        id: '1',
        sender: 'john.doe@company.com',
        subject: 'Account verification required',
        date: new Date('2025-01-15T10:30:00'),
        status: 'unread',
        messageBody: 'Hello, I need help with my account verification process. Could you please provide guidance on the next steps?'
      },
      {
        id: '2',
        sender: 'jane.smith@company.com',
        subject: 'Transaction inquiry',
        date: new Date('2025-01-14T15:45:00'),
        status: 'read',
        messageBody: 'I have a question about a recent transaction on my account. The reference number is TXN12345.'
      },
      {
        id: '3',
        sender: 'mike.johnson@company.com',
        subject: 'Password reset request',
        date: new Date('2025-01-13T09:15:00'),
        status: 'unread',
        messageBody: 'I am unable to reset my password using the standard process. Please assist.'
      },
      {
        id: '4',
        sender: 'sarah.wilson@company.com',
        subject: 'Account balance discrepancy',
        date: new Date('2025-01-12T14:20:00'),
        status: 'read',
        messageBody: 'I noticed a discrepancy in my account balance. Could you please review and provide clarification?'
      }
    ];
  }

  getMessages(): Observable<Message[]> {
    return this.messages$;
  }

  getMessageById(id: string): Observable<Message | undefined> {
    const messages = this.messagesSource.value;
    const message = messages.find(m => m.id === id);
    return of(message).pipe(delay(100));
  }

  markAsRead(messageId: string): void {
    const messages = this.messagesSource.value;
    const message = messages.find(m => m.id === messageId);
    if (message && message.status === 'unread') {
      message.status = 'read';
      this.messagesSource.next([...messages]);
    }
  }

  sendMessage(messageRequest: SendMessageRequest): Observable<boolean> {
    // Mock sending message - in real app, this would call an API
    console.log('Sending message:', messageRequest);
    
    // Simulate API delay
    return of(true).pipe(delay(1000));
  }

  getTopics(): string[] {
    return [
      'Account Issues',
      'Transaction Inquiries',
      'Technical Support',
      'General Questions',
      'Billing Questions',
      'Product Information'
    ];
  }

  getLanguages(): string[] {
    return ['English', 'Spanish', 'French', 'German', 'Chinese'];
  }

  getProducts(): string[] {
    return [
      'Checking Account',
      'Savings Account',
      'Credit Card',
      'Loan Services',
      'Investment Services',
      'Online Banking'
    ];
  }

  getEnvironments(): string[] {
    return ['DEV', 'UAT', 'PROD', 'COB'];
  }
}
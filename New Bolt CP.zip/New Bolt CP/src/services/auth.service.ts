import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface User {
  username: string;
  email: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSource = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSource.asObservable();

  private isAuthenticatedSource = new BehaviorSubject<boolean>(false);
  public isAuthenticated$ = this.isAuthenticatedSource.asObservable();

  login(username: string, password: string): boolean {
    // Mock authentication - in real app, this would call an API
    if (username && password) {
      const user: User = {
        username: username,
        email: `${username}@company.com`
      };
      
      this.currentUserSource.next(user);
      this.isAuthenticatedSource.next(true);
      
      // Store in sessionStorage for persistence
      sessionStorage.setItem('currentUser', JSON.stringify(user));
      sessionStorage.setItem('isAuthenticated', 'true');
      
      return true;
    }
    return false;
  }

  logout(): void {
    this.currentUserSource.next(null);
    this.isAuthenticatedSource.next(false);
    sessionStorage.removeItem('currentUser');
    sessionStorage.removeItem('isAuthenticated');
  }

  checkAuthStatus(): void {
    const storedUser = sessionStorage.getItem('currentUser');
    const isAuth = sessionStorage.getItem('isAuthenticated');
    
    if (storedUser && isAuth === 'true') {
      this.currentUserSource.next(JSON.parse(storedUser));
      this.isAuthenticatedSource.next(true);
    }
  }

  getCurrentUser(): User | null {
    return this.currentUserSource.value;
  }
}
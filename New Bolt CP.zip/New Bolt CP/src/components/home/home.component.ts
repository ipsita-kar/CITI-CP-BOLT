import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { Observable } from 'rxjs';
import { AuthService, User } from '../../services/auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule
  ],
  template: `
    <div class="home-container">
      <mat-card class="welcome-card">
        <mat-card-header>
          <mat-card-title class="welcome-title">
            <mat-icon class="welcome-icon">waving_hand</mat-icon>
            Welcome, {{ (currentUser$ | async)?.username }}!
          </mat-card-title>
        </mat-card-header>
        
        <mat-card-content>
          <div class="instructions">
            <h3 class="instructions-title">How to use the Secure Messaging Portal:</h3>
            
            <div class="instruction-item">
              <div class="instruction-number">1</div>
              <div class="instruction-content">
                <p>To send a secure message to a customer, click 
                  <strong>Send a new message</strong>.</p>
                <button 
                  mat-raised-button 
                  color="primary" 
                  routerLink="/send-message"
                  class="action-button">
                  <mat-icon>send</mat-icon>
                  Send a New Message
                </button>
              </div>
            </div>
            
            <mat-divider class="instruction-divider"></mat-divider>
            
            <div class="instruction-item">
              <div class="instruction-number">2</div>
              <div class="instruction-content">
                <p>To view customer replies, click 
                  <strong>Customer Inbox</strong>.</p>
                <button 
                  mat-raised-button 
                  color="accent" 
                  routerLink="/inbox"
                  class="action-button">
                  <mat-icon>inbox</mat-icon>
                  Customer Inbox
                </button>
              </div>
            </div>
          </div>
        </mat-card-content>
      </mat-card>

      <div class="stats-grid">
        <mat-card class="stat-card">
          <mat-card-content>
            <div class="stat-content">
              <mat-icon class="stat-icon unread">mark_email_unread</mat-icon>
              <div class="stat-text">
                <h3>4</h3>
                <p>Unread Messages</p>
              </div>
            </div>
          </mat-card-content>
        </mat-card>

        <mat-card class="stat-card">
          <mat-card-content>
            <div class="stat-content">
              <mat-icon class="stat-icon sent">send</mat-icon>
              <div class="stat-text">
                <h3>12</h3>
                <p>Sent Today</p>
              </div>
            </div>
          </mat-card-content>
        </mat-card>

        <mat-card class="stat-card">
          <mat-card-content>
            <div class="stat-content">
              <mat-icon class="stat-icon total">email</mat-icon>
              <div class="stat-text">
                <h3>47</h3>
                <p>Total Messages</p>
              </div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .home-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }

    .welcome-card {
      margin-bottom: 32px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .welcome-title {
      display: flex;
      align-items: center;
      gap: 12px;
      color: #1976d2;
      font-size: 28px;
    }

    .welcome-icon {
      font-size: 32px;
      color: #ff9800;
    }

    .instructions {
      margin-top: 24px;
    }

    .instructions-title {
      color: #333;
      margin-bottom: 24px;
      font-weight: 500;
    }

    .instruction-item {
      display: flex;
      align-items: flex-start;
      gap: 20px;
      margin-bottom: 24px;
    }

    .instruction-number {
      background-color: #1976d2;
      color: white;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      flex-shrink: 0;
    }

    .instruction-content {
      flex: 1;
    }

    .instruction-content p {
      margin-bottom: 12px;
      line-height: 1.6;
    }

    .action-button {
      margin-top: 8px;
    }

    .instruction-divider {
      margin: 32px 0;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-top: 32px;
    }

    .stat-card {
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .stat-content {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .stat-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
    }

    .stat-icon.unread {
      color: #f44336;
    }

    .stat-icon.sent {
      color: #4caf50;
    }

    .stat-icon.total {
      color: #2196f3;
    }

    .stat-text h3 {
      margin: 0;
      font-size: 32px;
      font-weight: 600;
    }

    .stat-text p {
      margin: 4px 0 0 0;
      color: #666;
      font-size: 14px;
    }

    @media (max-width: 768px) {
      .home-container {
        padding: 16px;
      }

      .welcome-title {
        font-size: 24px;
      }

      .instruction-item {
        flex-direction: column;
        gap: 12px;
      }

      .stats-grid {
        grid-template-columns: 1fr;
        gap: 16px;
      }
    }
  `]
})
export class HomeComponent implements OnInit {
  currentUser$: Observable<User | null>;

  constructor(private authService: AuthService) {
    this.currentUser$ = this.authService.currentUser$;
  }

  ngOnInit(): void {}
}
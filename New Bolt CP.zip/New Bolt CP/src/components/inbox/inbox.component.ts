import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatBadgeModule } from '@angular/material/badge';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
import { MessageService, Message } from '../../services/message.service';
import { MessageDialogComponent } from './message-dialog.component';

@Component({
  selector: 'app-inbox',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatBadgeModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule
  ],
  template: `
    <div class="inbox-container">
      <mat-card class="inbox-card">
        <mat-card-header>
          <mat-card-title class="inbox-title">
            <mat-icon>inbox</mat-icon>
            Customer Inbox
            <span 
              class="unread-badge"
              matBadge="{{ unreadCount }}"
              matBadgeColor="warn"
              matBadgeSize="small"
              *ngIf="unreadCount > 0">
            </span>
          </mat-card-title>
        </mat-card-header>

        <mat-card-content>
          <div class="inbox-toolbar">
            <mat-form-field appearance="outline" class="search-field">
              <mat-label>Search messages</mat-label>
              <input 
                matInput 
                [(ngModel)]="searchTerm"
                (ngModelChange)="applyFilter()"
                placeholder="Search by sender, subject...">
              <mat-icon matSuffix>search</mat-icon>
            </mat-form-field>

            <div class="inbox-stats">
              <span class="stat-item">
                <mat-icon>email</mat-icon>
                {{ totalMessages }} Total
              </span>
              <span class="stat-item unread" *ngIf="unreadCount > 0">
                <mat-icon>mark_email_unread</mat-icon>
                {{ unreadCount }} Unread
              </span>
            </div>
          </div>

          <div class="table-container">
            <table mat-table [dataSource]="filteredMessages" class="inbox-table">
              
              <!-- Sender Column -->
              <ng-container matColumnDef="sender">
                <th mat-header-cell *matHeaderCellDef>Sender</th>
                <td mat-cell *matCellDef="let message" class="sender-cell">
                  <div class="sender-info">
                    <mat-icon class="sender-icon">account_circle</mat-icon>
                    <span>{{ message.sender }}</span>
                  </div>
                </td>
              </ng-container>

              <!-- Subject Column -->
              <ng-container matColumnDef="subject">
                <th mat-header-cell *matHeaderCellDef>Subject</th>
                <td mat-cell *matCellDef="let message" class="subject-cell">
                  <span [ngClass]="message.status">{{ message.subject }}</span>
                </td>
              </ng-container>

              <!-- Date Column -->
              <ng-container matColumnDef="date">
                <th mat-header-cell *matHeaderCellDef>Date</th>
                <td mat-cell *matCellDef="let message" class="date-cell">
                  {{ message.date | date:'medium' }}
                </td>
              </ng-container>

              <!-- Status Column -->
              <ng-container matColumnDef="status">
                <th mat-header-cell *matHeaderCellDef>Status</th>
                <td mat-cell *matCellDef="let message" class="status-cell">
                  <mat-icon 
                    [ngClass]="'status-' + message.status"
                    [title]="message.status">
                    {{ message.status === 'unread' ? 'mark_email_unread' : 'drafts' }}
                  </mat-icon>
                  <span [ngClass]="'status-' + message.status">
                    {{ message.status | titlecase }}
                  </span>
                </td>
              </ng-container>

              <!-- Actions Column -->
              <ng-container matColumnDef="actions">
                <th mat-header-cell *matHeaderCellDef>Actions</th>
                <td mat-cell *matCellDef="let message" class="actions-cell">
                  <button 
                    mat-icon-button 
                    color="primary"
                    (click)="openMessage(message)"
                    title="View message">
                    <mat-icon>visibility</mat-icon>
                  </button>
                </td>
              </ng-container>

              <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
              <tr 
                mat-row 
                *matRowDef="let message; columns: displayedColumns;"
                (click)="openMessage(message)"
                [ngClass]="{'unread-row': message.status === 'unread'}"
                class="message-row">
              </tr>
            </table>

            <div class="no-messages" *ngIf="filteredMessages.length === 0">
              <mat-icon>inbox</mat-icon>
              <h3>No messages found</h3>
              <p>{{ searchTerm ? 'Try adjusting your search criteria' : 'Your inbox is empty' }}</p>
            </div>
          </div>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .inbox-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }

    .inbox-card {
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .inbox-title {
      display: flex;
      align-items: center;
      gap: 12px;
      color: #1976d2;
      font-size: 24px;
    }

    .unread-badge {
      margin-left: 8px;
    }

    .inbox-toolbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
      flex-wrap: wrap;
      gap: 16px;
    }

    .search-field {
      min-width: 300px;
      flex: 1;
    }

    .inbox-stats {
      display: flex;
      gap: 24px;
      align-items: center;
    }

    .stat-item {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 14px;
      color: #666;
    }

    .stat-item.unread {
      color: #f44336;
      font-weight: 500;
    }

    .table-container {
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .inbox-table {
      width: 100%;
      background: white;
    }

    .message-row {
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .message-row:hover {
      background-color: #f5f5f5;
    }

    .unread-row {
      background-color: #e3f2fd;
    }

    .unread-row:hover {
      background-color: #bbdefb;
    }

    .sender-cell {
      width: 30%;
    }

    .sender-info {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .sender-icon {
      color: #666;
      font-size: 20px;
    }

    .subject-cell {
      width: 35%;
      font-weight: 500;
    }

    .date-cell {
      width: 20%;
      color: #666;
      font-size: 14px;
    }

    .status-cell {
      width: 10%;
    }

    .status-cell {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .status-unread {
      color: #f44336;
      font-weight: 600;
    }

    .status-read {
      color: #666;
    }

    .actions-cell {
      width: 5%;
    }

    .no-messages {
      text-align: center;
      padding: 60px 20px;
      color: #666;
    }

    .no-messages mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      margin-bottom: 16px;
      color: #ccc;
    }

    .no-messages h3 {
      margin-bottom: 8px;
    }

    @media (max-width: 768px) {
      .inbox-container {
        padding: 16px;
      }

      .inbox-toolbar {
        flex-direction: column;
        align-items: stretch;
      }

      .search-field {
        min-width: unset;
      }

      .inbox-stats {
        justify-content: center;
      }

      .sender-cell,
      .subject-cell,
      .date-cell,
      .status-cell,
      .actions-cell {
        width: auto;
      }

      .date-cell {
        display: none;
      }

      .inbox-table .mat-column-date {
        display: none;
      }
    }
  `]
})
export class InboxComponent implements OnInit {
  messages$: Observable<Message[]>;
  messages: Message[] = [];
  filteredMessages: Message[] = [];
  searchTerm = '';
  
  displayedColumns: string[] = ['sender', 'subject', 'date', 'status', 'actions'];
  
  totalMessages = 0;
  unreadCount = 0;

  constructor(
    private messageService: MessageService,
    private dialog: MatDialog
  ) {
    this.messages$ = this.messageService.getMessages();
  }

  ngOnInit(): void {
    this.messages$.subscribe(messages => {
      this.messages = messages;
      this.filteredMessages = messages;
      this.updateStats();
    });
  }

  applyFilter(): void {
    if (!this.searchTerm) {
      this.filteredMessages = this.messages;
    } else {
      const term = this.searchTerm.toLowerCase();
      this.filteredMessages = this.messages.filter(message =>
        message.sender.toLowerCase().includes(term) ||
        message.subject.toLowerCase().includes(term) ||
        message.messageBody.toLowerCase().includes(term)
      );
    }
  }

  openMessage(message: Message): void {
    const dialogRef = this.dialog.open(MessageDialogComponent, {
      width: '700px',
      maxWidth: '90vw',
      data: message
    });

    // Mark as read when opening
    if (message.status === 'unread') {
      this.messageService.markAsRead(message.id);
    }

    dialogRef.afterClosed().subscribe(() => {
      this.updateStats();
    });
  }

  private updateStats(): void {
    this.totalMessages = this.messages.length;
    this.unreadCount = this.messages.filter(m => m.status === 'unread').length;
  }
}